rm -rf /usr/local/nginx/conf/vhost/baktemp/*
